# Liens vers les "repos" de cours

* [Adrien](https://github.com/AdriWard/VisuelDon)
* [Andrea](https://github.com/Andreanefer/ViusalDonM47)
* [Audrey](https://github.com/AudilaraZ/VisualDon)
* [Emilie]( https://github.com/emilie-imhof/visualisation-de-donnees)
* [Ingrid Elena](https://github.com/ingridsorg/datavis)
* [Jean](https://github.com/JeanHerbaut/DataVis)
* [Julie](https://github.com/julie-greset/visualdon/)
* [Kevin](https://github.com/Saiykoh/VisuDon)
* [Laurie](https://github.com/loumloum/VisualDon)
* [Leyna](https://github.com/leyGir/VisualDon)
* [Léonard](https://github.com/LeonardMichiels/VisualDon)
* [Majka](https://github.com/majka-voide/VisualDon-cours)
* [Michelle](https://github.com/michelle-po/VisualDon)
* [Olivia](https://github.com/olivia-prad/VisualDon)
* [Robin](https://github.com/robiiiiiiiiiiiin/VisualDon)
* [Rui Filipe](https://github.com/nobrega1/VisualDon)
* [Soraya](https://github.com/Soraya97/VisualDon)
* [Stéphane](https://github.com/Stephane-panda/datavis)
* [Sébastien](https://github.com/sebastienRay/VisualDon)
* [Yasmine](https://github.com/yasminehamdan/VisualDonn)

## Créer un repo personnel pour le cours

* Créer un dossier `mon-cours`
* À l'intérieur duquel vous avez un dossier par jour de cours (ex: `mon-cours/20200221`)
* Ajouter `.gitignore`
* `git init`
* Vérifier ce qu'il y a à ajouter `git status`
* `git add .`
* `git commit -m "mon dessin"`
* Créer un repo `mon-cours` sur github
