# Mise en place d'un projet chartjs

* [Documentation `chartjs`](https://www.chartjs.org/docs/latest/)

## Utilisation

Creez un nouveau dossier au nom de votre projet, copiez cette mise en place et installez les librairies nécessaires:

```
mkdir mon-projet
cd mon-projet
npx degit idris-maps/heig-datavis-2020/template/chartjs-batons
npm install
```
