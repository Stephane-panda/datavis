# Mise en place d'un projet d3

## Utilisation

Creez un nouveau dossier au nom de votre projet, copiez cette mise en place et installez les librairies nécessaires:

```
mkdir mon-projet
cd mon-projet
npx degit idris-maps/heig-datavis-2020/template/d3-batons
npm install
```