# Mise en place d'un projet billboard

* [Documentation `billboard`](https://naver.github.io/billboard.js/demo/)

## Utilisation

Creez un nouveau dossier au nom de votre projet, copiez cette mise en place et installez les librairies nécessaires:

```
mkdir mon-projet
cd mon-projet
npx degit idris-maps/heig-datavis-2020/template/billboard-batons
npm install
```
