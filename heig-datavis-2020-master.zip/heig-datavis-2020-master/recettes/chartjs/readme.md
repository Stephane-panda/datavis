# recette chartjs

* [Docs](https://www.chartjs.org/docs/latest/)
* [site](http://heig-datavis2020.surge.sh/recettes/chartjs/dist/)

## Installation

```
npm install chart.js --save
```
