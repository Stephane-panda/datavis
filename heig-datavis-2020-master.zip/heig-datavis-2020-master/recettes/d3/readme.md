# recette d3

* [site](http://heig-datavis2020.surge.sh/recettes/d3/dist/)

## Installation

```
npm install d3 --save
```