# Changer les données d'un graphique billboard

Dans cet exemple, nous supposons que vous souhaitez changer les données représentées quand un utilisateur clique un bouton. Les données contiennent quelques villes vaudoise. Quand la page est chargée, un graphique en bâtons est affiché avec la population par ville. Si le bouton est cliqué, le graphique affiche la superficie des villes.

Le [résultat](http://heig-datavis2020.surge.sh/20200501/billboard/)

Lisez le code commenté dans [`src/index.js`](src/index.js)